package parsingUI; 

public class LaunchUI {
	public static void main (String[] args) 
	{
		ParseInterface f = new ParseInterface();     
	}
}
