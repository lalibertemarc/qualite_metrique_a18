package packageModels;

public enum Multiplicity {
	ONE,
	MANY,
	ONE_OR_MANY,
	OPTIONALLY_ONE,
	UNDEFINED
}