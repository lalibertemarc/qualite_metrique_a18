package packageModels;

public interface Modelable {

	String getIdentifier();

	String getDetails();

	void setIdentifier(String id);
	
	void setDetails(String details);
}