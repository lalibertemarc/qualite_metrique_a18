package packageModels;
public interface Returnable {

	String getType();
	
	void setType(String type);
}