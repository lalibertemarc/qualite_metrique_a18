# Comment Executer le programme

1. Executer dans la commande `java -cp . parsingUI/LaunchUI` dans le fichier remise



